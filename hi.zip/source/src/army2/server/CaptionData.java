package army2.server;

import java.util.ArrayList;

/**
 *
 * @author ASD
 */
public class CaptionData {

    public static final class CaptionEntry {
        int level;
        String caption;
    }

    public static ArrayList<CaptionEntry> entrys;
    
}
